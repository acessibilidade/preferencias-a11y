/* A11Y Preferences 1.10.0 — independent implementation, no dependencies. */
(() => {
  'use strict';
  const script = document.currentScript;
  const cssURL = new URL('../css/preferences.css?v=1.10.0-reflow2', script.src).href;
  const key = 'fm-preferencias-v1';
  const visibilityKey = `fm-preferencias-hidden-v1:${location.pathname}${location.search}`;
  const compactKey = `fm-preferencias-compact-v1:${location.pathname}${location.search}`;
  const options = {
    size: ['original', '125', '150', '175', '200'],
    line: ['original', '150', '175', '200'],
    letter: ['original', '005', '010', '015'],
    word: ['original', '010', '020', '030'],
    inputs: ['original', 'on'],
    font: ['original', 'system', 'serif', 'arial', 'atkinson', 'lexend', 'open-sans', 'verdana'],
    contrast: ['original', 'light', 'dark', 'yellow', 'sepia'],
    bold: ['original', 'on'],
    zoom: ['original', '125', '150', '175', '200', '300', '400'],
    mute: ['original', 'on'],
    motion: ['original', 'on']
  };
  // BEGIN ENGLISH TRANSLATIONS
  const english = {
    "Tamanho do texto": "Text size",
    "Espaçamento entre linhas": "Line spacing",
    "Espaçamento entre letras": "Letter spacing",
    "Espaçamento entre palavras": "Word spacing",
    "Destacar controles": "Highlight controls",
    "Desativado": "Off",
    "Ativado": "On",
    "Estilo de texto e fontes": "Text style and fonts",
    "Fonte do sistema": "System font",
    "Com serifa": "Serif",
    "Cor e contraste": "Color and contrast",
    "Preto sobre branco": "Black on white",
    "Branco sobre preto": "White on black",
    "Amarelo sobre preto": "Yellow on black",
    "Sépia": "Sepia",
    "Negrito": "Bold",
    "Aplicar zoom": "Zoom content",
    "Desabilitar sons": "Mute sounds",
    "Pausar animações": "Pause animations",
    "1,5": "1.5",
    "1,75": "1.75",
    "0,05 em": "0.05 em",
    "0,10 em": "0.10 em",
    "0,15 em": "0.15 em",
    "0,20 em": "0.20 em",
    "0,30 em": "0.30 em",
    "exibir preferências": "show preferences",
    "— abre o painel na mesma página": "— opens the panel on this page",
    "configure do seu jeito": "make it your own",
    "Preferências": "Preferences",
    "Fechar preferências": "Close preferences",
    "Fechar": "Close",
    "Ajuste a apresentação desta página para você.": "Adjust this page's presentation to suit you.",
    "deixar esta camada flutuante": "make this panel float",
    "Arraste pelo botão Mover painel, use as setas do teclado nesse botão ou selecione uma direção abaixo.": "Drag using the Move panel button, use the arrow keys on that button, or choose a direction below.",
    "Mover painel": "Move panel",
    "Mover painel por direção": "Move panel by direction",
    "Mover painel para a esquerda": "Move panel left",
    "Mover painel para cima": "Move panel up",
    "Mover painel para baixo": "Move panel down",
    "Mover painel para a direita": "Move panel right",
    "exibir todas as preferências": "show all preferences",
    "exibir mais preferências": "show more preferences",
    "exibir ícone pequeno da ferramenta": "show a small tool icon",
    "Substitui o texto do botão pelo ícone de preferências nesta página. Desmarque para voltar a exibir o texto.": "Replaces the button text with the preferences icon on this page. Uncheck to show the text again.",
    "não exibir o botão de preferências nessa página": "hide the preferences button on this page",
    "Ao selecionar essa opção, após fechar a ferramenta o botão não será mais exibido. Para o botão ser exibido novamente, será preciso limpar o cache do navegador, incluindo os dados deste site.": "If you select this option, the button will no longer appear after you close the tool. To show it again, clear your browser's cache, including this site's data.",
    "Restaurar padrão": "Restore defaults",
    "Ajustar preferências não corrigem barreiras de acessibilidade do site.": "Adjusting preferences does not fix the site's accessibility barriers.",
    "Versão 1.10.0": "Version 1.10.0",
    "Conheça o projeto “": "Explore the project “",
    "Preferências de Acessibilidade": "Accessibility Preferences",
    "(abre em uma nova aba)": "(opens in a new tab)",
    "Este é um projeto de": "This project is",
    "código aberto": "open source",
    "canto superior esquerdo": "top left",
    "centro superior": "top center",
    "canto superior direito": "top right",
    "centro à esquerda": "center left",
    "centro": "center",
    "centro à direita": "center right",
    "canto inferior esquerdo": "bottom left",
    "centro inferior": "bottom center",
    "canto inferior direito": "bottom right",
    "à esquerda": "on the left",
    "à direita": "on the right",
    "acima": "at the top",
    "abaixo": "at the bottom",
    "O painel não foi movido.": "The panel did not move.",
    "para a esquerda": "left",
    "para a direita": "right",
    "para cima": "up",
    "para baixo": "down",
    " e ": " and ",
    "Painel flutuante ativado.": "Floating panel enabled.",
    "Painel devolvido à posição original.": "Panel returned to its original position.",
    "Botão de preferências exibido como ícone.": "Preferences button displayed as an icon.",
    "Botão de preferências exibido com texto.": "Preferences button displayed with text.",
    "Amplia o conteúdo do site. O painel mantém seu tamanho. Não altera o zoom nativo do navegador.": "Enlarges the site's content. The panel keeps its size. Does not change the browser's native zoom.",
    "Silencia áudios e vídeos HTML desta página. Não controla Web Audio nem players de terceiros em iframes.": "Mutes HTML audio and video on this page. Does not control Web Audio or third-party players in iframes.",
    "Pausa vídeos HTML e animações CSS/Web Animations. GIFs, canvas, animações por scripts e iframes podem continuar. Vídeos não reiniciam automaticamente ao desmarcar.": "Pauses HTML videos and CSS/Web Animations. GIFs, canvas, scripted animations, and iframes may continue. Videos do not resume automatically when unchecked.",
    "Configurado": "Configured",
    "Alterações aplicadas nesta página.": "Changes applied to this page.",
    " O navegador não permitiu salvar as preferências.": " The browser did not allow preferences to be saved.",
    "Preferências restauradas.": "Preferences restored.",
    "Preferências salvas apenas neste navegador, por site.": "Preferences saved only in this browser, per site.",
    "Diminuir: {label}": "Decrease: {label}",
    "Aumentar: {label}": "Increase: {label}",
    "Posição aproximada: {position} da área disponível da tela.": "Approximate position: {position} of the available screen area.",
    "Limite {direction} atingido. O painel não foi movido.": "Boundary {direction} reached. The panel did not move.",
    "Painel movido {directions}.": "Panel moved {directions}."
  };
  // END ENGLISH TRANSLATIONS
  function init() {
    const isEnglish = (script.dataset.lang || 'en-US').toLowerCase().startsWith('en');
    function t(message, values = {}) {
      const translated = isEnglish ? (english[message] || message) : message;
      return translated.replace(/\{(\w+)\}/g, (_, name) => values[name] ?? `{${name}}`);
    }
    if (document.getElementById('fm-preferences')) return;
    const root = document.documentElement;
    const host = document.createElement('div');
    host.id = 'fm-preferences';
    host.lang = isEnglish ? 'en-US' : 'pt-BR';
    const shadow = host.attachShadow({ mode: 'open' });
    const sheet = document.createElement('link');
    sheet.rel = 'stylesheet';
    sheet.href = cssURL;
    document.head.append(sheet);
    const panelSheet = sheet.cloneNode();
    shadow.append(panelSheet);
    const labels = {
      size: [t('Tamanho do texto'), ['Original (100%)', '125%', '150%', '175%', '200%']],
      line: [t('Espaçamento entre linhas'), ['Original', t('1,5'), t('1,75'), '2']],
      letter: [t('Espaçamento entre letras'), ['Original', t('0,05 em'), t('0,10 em'), t('0,15 em')]],
      word: [t('Espaçamento entre palavras'), ['Original', t('0,10 em'), t('0,20 em'), t('0,30 em')]],
      inputs: [t('Destacar controles'), [t('Desativado'), t('Ativado')]],
      font: [t('Estilo de texto e fontes'), ['Original', t('Fonte do sistema'), t('Com serifa'), 'Arial', 'Atkinson', 'Lexend', 'Open Sans', 'Verdana']],
      contrast: [t('Cor e contraste'), ['Original', t('Preto sobre branco'), t('Branco sobre preto'), t('Amarelo sobre preto'), t('Sépia')]],
      bold: [t('Negrito'), []],
      zoom: [t('Aplicar zoom'), ['Original (100%)', '125%', '150%', '175%', '200%', '300%', '400%']],
      mute: [t('Desabilitar sons'), []],
      motion: [t('Pausar animações'), []]
    };
    const container = document.createElement('div');
    container.className = 'preferences-dock';
    container.innerHTML = `
      <a class="trigger" href="#fm-panel" tabindex="0" aria-controls="fm-panel" aria-expanded="false"><span class="trigger-label">${t("exibir preferências")}</span><svg class="trigger-icon" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M480-720q-33 0-56.5-23.5T400-800q0-33 23.5-56.5T480-880q33 0 56.5 23.5T560-800q0 33-23.5 56.5T480-720ZM360-120v-480q-68-6-127-16t-113-24l20-80q75 20 159 30t181 10q97 0 181-10t159-30l20 80q-54 14-113 24t-127 16v480h-80v-240h-80v240h-80Zm440-320q-17 0-28.5-11.5T760-480q0-17 11.5-28.5T800-520q17 0 28.5 11.5T840-480q0 17-11.5 28.5T800-440Zm0 160q-17 0-28.5-11.5T760-320q0-17 11.5-28.5T800-360q17 0 28.5 11.5T840-320q0 17-11.5 28.5T800-280Zm0 160q-17 0-28.5-11.5T760-160q0-17 11.5-28.5T800-200q17 0 28.5 11.5T840-160q0 17-11.5 28.5T800-120Z"/></svg><span class="sr-only"> ${t("— abre o painel na mesma página")}</span></a>
      <section id="fm-panel" class="panel" aria-labelledby="fm-title" hidden>
        <header class="panel-header">
          <div><p class="eyebrow">${t("configure do seu jeito")}</p><h2 id="fm-title" tabindex="-1">${t("Preferências")}</h2></div>
          <button type="button" class="close" aria-label="${t("Fechar preferências")}">${t("Fechar")}</button>
        </header>
        <div class="panel-content">
          <p class="intro">${t("Ajuste a apresentação desta página para você.")}</p>
          <label class="show-all checkbox-label" for="fm-floating">
            <input id="fm-floating" type="checkbox" aria-describedby="fm-floating-help">
            <span>${t("deixar esta camada flutuante")}</span>
          </label>
          <div class="floating-controls" hidden>
            <p id="fm-floating-help">${t("Arraste pelo botão Mover painel, use as setas do teclado nesse botão ou selecione uma direção abaixo.")}</p>
            <button type="button" class="move-handle" aria-describedby="fm-panel-position fm-floating-help">${t("Mover painel")}</button>
            <p id="fm-panel-position" class="sr-only"></p>
            <p class="sr-only move-status" role="status" aria-live="polite" aria-atomic="true"></p>
            <div class="move-directions" role="group" aria-label="${t("Mover painel por direção")}">
              <button type="button" data-move="left" aria-label="${t("Mover painel para a esquerda")}">←</button>
              <button type="button" data-move="up" aria-label="${t("Mover painel para cima")}">↑</button>
              <button type="button" data-move="down" aria-label="${t("Mover painel para baixo")}">↓</button>
              <button type="button" data-move="right" aria-label="${t("Mover painel para a direita")}">→</button>
            </div>
          </div>
          <label class="show-all checkbox-label" for="fm-show-all">
            <input id="fm-show-all" type="checkbox">
            <span>${t("exibir todas as preferências")}</span>
          </label>
          <div class="controls"></div>
          <details class="more-preferences">
            <summary>${t("exibir mais preferências")}</summary>
            <div class="extra-controls"></div>
          </details>
          <footer>
            <div class="visibility-option">
              <label class="visibility-label" for="fm-compact-trigger">
                <input id="fm-compact-trigger" type="checkbox" aria-describedby="fm-compact-help">
                <span>${t("exibir ícone pequeno da ferramenta")}</span>
              </label>
              <p id="fm-compact-help">${t("Substitui o texto do botão pelo ícone de preferências nesta página. Desmarque para voltar a exibir o texto.")}</p>
            </div>
            <div class="visibility-option">
              <label class="visibility-label" for="fm-hide-trigger">
                <input id="fm-hide-trigger" type="checkbox" aria-describedby="fm-hide-help">
                <span>${t("não exibir o botão de preferências nessa página")}</span>
              </label>
              <p id="fm-hide-help">${t("Ao selecionar essa opção, após fechar a ferramenta o botão não será mais exibido. Para o botão ser exibido novamente, será preciso limpar o cache do navegador, incluindo os dados deste site.")}</p>
            </div>
            <button type="button" class="reset">${t("Restaurar padrão")}</button>
            <p class="status" role="status"></p>
            <p class="note">${t("Ajustar preferências não corrigem barreiras de acessibilidade do site.")} <span class="version">${t("Versão 1.10.0")}</span></p>
            <p class="project-credit">${t("Conheça o projeto “")}<a href="http://preferenciasdeacessibilidade.com/" target="_blank" rel="noopener noreferrer">${t("Preferências de Acessibilidade")}<span class="sr-only"> ${t("(abre em uma nova aba)")}</span></a><svg class="external-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M19 19H5V5h7V3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z"/></svg>”.</p>
            <p class="project-credit">${t("Este é um projeto de")} <a href="https://github.com/acessibilidade/preferencias-a11y" target="_blank" rel="noopener noreferrer">${t("código aberto")}<span class="sr-only"> ${t("(abre em uma nova aba)")}</span></a><svg class="external-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M19 19H5V5h7V3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z"/></svg>.</p>
          </footer>
        </div>
      </section>`;
    shadow.append(container);
    document.body.append(host);
    const panel = shadow.querySelector('.panel');
    const trigger = shadow.querySelector('.trigger');
    const status = shadow.querySelector('.status');
    const floating = shadow.querySelector('#fm-floating');
    const floatingControls = shadow.querySelector('.floating-controls');
    const moveHandle = shadow.querySelector('.move-handle');
    // Runtime coordinates live in a stylesheet, never in inline HTML styles.
    const positionSheet = new CSSStyleSheet();
    positionSheet.replaceSync(':host .panel.is-floating { left: 0px; top: 0px; right: auto; }');
    shadow.adoptedStyleSheets = [...shadow.adoptedStyleSheets, positionSheet];
    const positionRule = positionSheet.cssRules[0];
    let drag = null;
    let announcementTimer;
    const positionDescription = shadow.querySelector('#fm-panel-position');
    const moveStatus = shadow.querySelector('.move-status');
    function describePosition() {
      const rect = panel.getBoundingClientRect();
      const viewport = window.visualViewport;
      const availableX = (viewport ? viewport.width : window.innerWidth) - rect.width;
      const availableY = (viewport ? viewport.height : window.innerHeight) - rect.height;
      const x = availableX > 1 ? (rect.left - (viewport?.offsetLeft || 0)) / availableX : 0.5;
      const y = availableY > 1 ? (rect.top - (viewport?.offsetTop || 0)) / availableY : 0.5;
      const column = x < 0.33 ? 0 : x > 0.67 ? 2 : 1;
      const row = y < 0.33 ? 0 : y > 0.67 ? 2 : 1;
      const regions = [
        [t('canto superior esquerdo'), t('centro superior'), t('canto superior direito')],
        [t('centro à esquerda'), t('centro'), t('centro à direita')],
        [t('canto inferior esquerdo'), t('centro inferior'), t('canto inferior direito')]
      ];
      const text = t('Posição aproximada: {position} da área disponível da tela.', { position: regions[row][column] });
      positionDescription.textContent = text;
      return text;
    }
    function announceMovement(message) {
      clearTimeout(announcementTimer);
      moveStatus.textContent = '';
      // Coalesce repeated keys and allow identical messages to be announced again.
      announcementTimer = setTimeout(() => {
        moveStatus.textContent = `${message} ${describePosition()}`;
      }, 180);
    }
    function describeMovement(before, direction) {
      const after = panel.getBoundingClientRect();
      const dx = after.left - before.left;
      const dy = after.top - before.top;
      if (Math.abs(dx) < 1 && Math.abs(dy) < 1) {
        const names = { left: t('à esquerda'), right: t('à direita'), up: t('acima'), down: t('abaixo') };
        announceMovement(direction ? t('Limite {direction} atingido. O painel não foi movido.', { direction: names[direction] }) : t('O painel não foi movido.'));
        return;
      }
      const movements = [];
      if (Math.abs(dx) >= 1) movements.push(dx < 0 ? t('para a esquerda') : t('para a direita'));
      if (Math.abs(dy) >= 1) movements.push(dy < 0 ? t('para cima') : t('para baixo'));
      announceMovement(t('Painel movido {directions}.', { directions: movements.join(t(' e ')) }));
    }

    function positionPanel(x, y) {
      const rect = panel.getBoundingClientRect();
      const viewport = window.visualViewport;
      const left = viewport ? viewport.offsetLeft : 0;
      const top = viewport ? viewport.offsetTop : 0;
      const width = viewport ? viewport.width : window.innerWidth;
      const height = viewport ? viewport.height : window.innerHeight;
      const scaleX = rect.width / panel.offsetWidth || 1;
      const scaleY = rect.height / panel.offsetHeight || 1;
      x = Math.max(left, Math.min(x, left + width - rect.width));
      y = Math.max(top, Math.min(y, top + height - rect.height));
      positionRule.style.left = `${x / scaleX}px`;
      positionRule.style.top = `${y / scaleY}px`;
      describePosition();
    }
    function stopDragging() {
      const finishedDrag = drag;
      drag = null;
      if (finishedDrag) {
        if (moveHandle.hasPointerCapture(finishedDrag.id)) moveHandle.releasePointerCapture(finishedDrag.id);
        describeMovement(finishedDrag.start);
      }
      moveHandle.classList.remove('is-dragging');
    }
    function setFloating(enabled) {
      stopDragging();
      const rect = panel.getBoundingClientRect();
      floating.checked = enabled;
      floatingControls.hidden = !enabled;
      panel.classList.toggle('is-floating', enabled);
      if (enabled) positionPanel(rect.left, rect.top);
      else {
        clearTimeout(announcementTimer);
        moveStatus.textContent = '';
      }
    }
    floating.addEventListener('change', () => {
      setFloating(floating.checked);
      status.textContent = floating.checked ? t('Painel flutuante ativado.') : t('Painel devolvido à posição original.');
    });
    moveHandle.addEventListener('pointerdown', event => {
      if (!floating.checked || !event.isPrimary || event.button !== 0) return;
      const rect = panel.getBoundingClientRect();
      drag = { id: event.pointerId, x: event.clientX - rect.left, y: event.clientY - rect.top, start: rect };
      moveHandle.setPointerCapture(event.pointerId);
      moveHandle.classList.add('is-dragging');
      moveHandle.focus({ preventScroll: true });
      event.preventDefault();
    });
    moveHandle.addEventListener('pointermove', event => {
      if (drag && drag.id === event.pointerId) positionPanel(event.clientX - drag.x, event.clientY - drag.y);
    });
    ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(type => moveHandle.addEventListener(type, stopDragging));
    const directions = { left: [-24, 0], right: [24, 0], up: [0, -24], down: [0, 24] };
    function movePanel(direction) {
      if (!floating.checked) return;
      const rect = panel.getBoundingClientRect();
      const [x, y] = directions[direction];
      positionPanel(rect.left + x, rect.top + y);
      describeMovement(rect, direction);
    }
    moveHandle.addEventListener('focus', describePosition);
    moveHandle.addEventListener('keydown', event => {
      const direction = { ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down' }[event.key];
      if (direction) { event.preventDefault(); movePanel(direction); }
    });
    shadow.querySelectorAll('[data-move]').forEach(button => {
      button.addEventListener('click', () => movePanel(button.dataset.move));
    });
    function constrainPanel() {
      if (!floating.checked || panel.hidden) return;
      const rect = panel.getBoundingClientRect();
      positionPanel(rect.left, rect.top);
    }
    window.addEventListener('resize', constrainPanel);
    window.visualViewport?.addEventListener('resize', constrainPanel);
    window.visualViewport?.addEventListener('scroll', constrainPanel);
    new ResizeObserver(constrainPanel).observe(panel);
    const hideTrigger = shadow.querySelector('#fm-hide-trigger');
    try { trigger.hidden = localStorage.getItem(visibilityKey) === 'true'; } catch (_) { /* Optional storage. */ }
    const compactTrigger = shadow.querySelector('#fm-compact-trigger');
    function applyCompactTrigger() {
      trigger.classList.toggle('trigger-compact', compactTrigger.checked);
      shadow.querySelector('.trigger-label').classList.toggle('sr-only', compactTrigger.checked);
    }
    try { compactTrigger.checked = localStorage.getItem(compactKey) === 'true'; } catch (_) { /* Optional storage. */ }
    applyCompactTrigger();
    compactTrigger.addEventListener('change', () => {
      applyCompactTrigger();
      try { localStorage.setItem(compactKey, String(compactTrigger.checked)); } catch (_) { /* Optional storage. */ }
      status.textContent = compactTrigger.checked ? t('Botão de preferências exibido como ícone.') : t('Botão de preferências exibido com texto.');
    });
    const state = {};
    const rangeNames = new Set(['zoom', 'size', 'line', 'letter', 'word']);
    const syncRanges = new Map();
    let saved = {};
    try { saved = JSON.parse(localStorage.getItem(key)) || {}; } catch (_) { /* Storage is optional. */ }
    for (const name of Object.keys(options)) {
      state[name] = options[name].includes(saved[name]) ? saved[name] : 'original';
      const row = document.createElement('div');
      row.className = 'control';
      const label = document.createElement('label');
      label.htmlFor = `fm-${name}`;
      label.textContent = labels[name][0];
      const checkbox = ['inputs', 'bold', 'mute', 'motion'].includes(name);
      const range = rangeNames.has(name);
      const control = document.createElement(checkbox || range ? 'input' : 'select');
      control.id = label.htmlFor;
      control.name = name;
      if (checkbox) {
        control.type = 'checkbox';
        control.checked = state[name] === 'on';
        label.className = 'checkbox-label';
        label.prepend(control);
        row.append(label);
      } else if (range) {
        control.type = 'range';
        control.min = '0';
        control.max = String(options[name].length - 1);
        control.step = '1';
        control.className = 'preference-range';
        const value = document.createElement('span');
        value.className = 'range-value';
        value.setAttribute('aria-hidden', 'true');
        const track = document.createElement('div');
        track.className = 'range-controls';
        const decrease = document.createElement('button');
        const increase = document.createElement('button');
        decrease.type = increase.type = 'button';
        decrease.textContent = '−';
        increase.textContent = '+';
        decrease.setAttribute('aria-label', t('Diminuir: {label}', { label: labels[name][0] }));
        increase.setAttribute('aria-label', t('Aumentar: {label}', { label: labels[name][0] }));
        const ticks = document.createElement('datalist');
        ticks.id = `fm-${name}-steps`;
        options[name].forEach((_, index) => ticks.append(new Option('', String(index))));
        control.setAttribute('list', ticks.id);
        const sync = () => {
          const index = options[name].indexOf(state[name]);
          const text = labels[name][1][index];
          control.value = String(index);
          control.setAttribute('aria-valuetext', text);
          value.textContent = text;
          decrease.setAttribute('aria-disabled', String(index === 0));
          increase.setAttribute('aria-disabled', String(index === options[name].length - 1));
        };
        syncRanges.set(name, sync);
        const update = index => {
          state[name] = options[name][index];
          sync();
          apply();
          persist();
        };
        [[decrease, -1], [increase, 1]].forEach(([button, delta]) => {
          button.addEventListener('click', () => {
            const index = options[name].indexOf(state[name]) + delta;
            if (index < 0 || index >= options[name].length) return;
            update(index);
            status.textContent = `${labels[name][0]}: ${labels[name][1][index]}.`;
          });
        });
        control.addEventListener('input', () => update(Number(control.value)));
        sync();
        track.append(decrease, control, increase);
        row.append(label, value, track, ticks);
      } else {
        options[name].forEach((value, index) => control.add(new Option(labels[name][1][index], value)));
        control.value = state[name];
        row.append(label, control);
      }
      const help = {
        zoom: t('Amplia o conteúdo do site. O painel mantém seu tamanho. Não altera o zoom nativo do navegador.'),
        mute: t('Silencia áudios e vídeos HTML desta página. Não controla Web Audio nem players de terceiros em iframes.'),
        motion: t('Pausa vídeos HTML e animações CSS/Web Animations. GIFs, canvas, animações por scripts e iframes podem continuar. Vídeos não reiniciam automaticamente ao desmarcar.')
      };
      if (help[name]) {
        const description = document.createElement('p');
        description.className = 'control-help';
        description.id = `fm-${name}-help`;
        description.textContent = help[name];
        control.setAttribute('aria-describedby', description.id);
        row.append(description);
      }
      shadow.querySelector('.controls').append(row);
      if (name === 'bold') shadow.querySelector('#fm-font').parentElement.append(row);
      if (!range) control.addEventListener('change', () => {
        state[name] = checkbox ? (control.checked ? 'on' : 'original') : control.value;
        apply();
        persist();
      });
    }
    const primaryOrder = ['zoom', 'contrast', 'inputs', 'font', 'size', 'line', 'letter', 'word'];
    const primaryControls = shadow.querySelector('.controls');
    const configuredGroups = [];
    function registerConfiguredGroup(group, names) {
      const badge = document.createElement('span');
      badge.className = 'configured-badge';
      badge.textContent = t('Configurado');
      badge.hidden = true;
      group.querySelector('summary').append(' ', badge);
      configuredGroups.push({ group, names, badge });
    }
    primaryOrder.forEach(name => {
      const row = shadow.querySelector(`#fm-${name}`).closest('.control');
      const group = document.createElement('details');
      group.className = 'preference-group';
      group.name = 'fm-preference-groups';
      const summary = document.createElement('summary');
      summary.textContent = labels[name][0];
      if (name !== 'inputs') row.querySelector('label').classList.add('sr-only');
      group.append(summary, row);
      registerConfiguredGroup(group, name === 'font' ? ['font', 'bold'] : [name]);
      primaryControls.append(group);
    });
    const morePreferences = shadow.querySelector('.more-preferences');
    morePreferences.name = 'fm-preference-groups';
    registerConfiguredGroup(morePreferences, ['motion', 'mute']);
    // Also enforce exclusivity in browsers without support for details[name].
    const groups = [...shadow.querySelectorAll('details[name="fm-preference-groups"]')];
    const showAll = shadow.querySelector('#fm-show-all');
    function setAllGroups(expanded) {
      showAll.checked = expanded;
      showAll.indeterminate = false;
      groups.forEach(group => group.removeAttribute('name'));
      groups.forEach(group => { group.open = expanded; });
      if (!expanded) groups.forEach(group => { group.name = 'fm-preference-groups'; });
    }
    showAll.addEventListener('change', () => setAllGroups(showAll.checked));
    groups.forEach(group => group.addEventListener('toggle', () => {
      if (showAll.checked) {
        showAll.indeterminate = !groups.every(item => item.open);
        return;
      }
      if (!group.open) return;
      groups.forEach(other => { if (other !== group) other.open = false; });
    }));
    const extraControls = shadow.querySelector('.extra-controls');
    ['motion', 'mute'].forEach(name => extraControls.append(shadow.querySelector(`#fm-${name}`).closest('.control')));
    // Old persisted "simplify" values are deliberately not loaded in this version.
    root.removeAttribute('data-fm-simplify');
    document.querySelectorAll('[data-fm-hidden]').forEach(el => el.removeAttribute('data-fm-hidden'));
    const originalMuted = new Map();
    const pausedAnimations = new Set();
    let observing = false;
    let motionActive = false;
    function enforceMedia(media) {
      if (!(media instanceof HTMLMediaElement)) return;
      if (state.mute === 'on') {
        if (!originalMuted.has(media)) originalMuted.set(media, media.muted);
        if (!media.muted) media.muted = true;
      }
      if (state.motion === 'on' && media instanceof HTMLVideoElement && !media.paused) media.pause();
    }
    function pauseAnimations() {
      if (state.motion !== 'on' || !document.getAnimations) return;
      document.getAnimations().forEach(animation => {
        // CSS animations are paused by the stylesheet and restored by removing it.
        if (typeof CSSAnimation !== 'undefined' && animation instanceof CSSAnimation) return;
        if (animation.playState === 'running' || animation.pending) {
          animation.pause();
          pausedAnimations.add(animation);
        }
      });
    }
    const observer = new MutationObserver(records => {
      for (const record of records) {
        for (const node of record.addedNodes) {
          if (node.nodeType !== 1 || node === host) continue;
          enforceMedia(node);
          node.querySelectorAll('audio, video').forEach(enforceMedia);
        }
      }
      pauseAnimations();
    });
    ['play', 'playing', 'volumechange', 'loadedmetadata'].forEach(type => {
      document.addEventListener(type, event => enforceMedia(event.target), true);
    });
    document.addEventListener('animationstart', pauseAnimations, true);
    function applyMedia() {
      if (state.mute !== 'on') {
        originalMuted.forEach((muted, media) => { media.muted = muted; });
        originalMuted.clear();
      }
      document.querySelectorAll('audio, video').forEach(enforceMedia);
      if (state.motion === 'on') pauseAnimations();
      else if (motionActive) {
        pausedAnimations.forEach(animation => {
          if (animation.playState === 'paused') animation.play();
        });
        pausedAnimations.clear();
      }
      motionActive = state.motion === 'on';
      const needed = state.mute === 'on' || motionActive;
      if (needed && !observing) observer.observe(document.body, { childList: true, subtree: true });
      else if (!needed && observing) observer.disconnect();
      observing = needed;
    }
    function apply() {
      for (const [name, value] of Object.entries(state)) {
        if (value === 'original') root.removeAttribute(`data-fm-${name}`);
        else root.setAttribute(`data-fm-${name}`, value);
      }
      configuredGroups.forEach(({ group, names, badge }) => {
        const configured = names.some(name => state[name] !== 'original');
        badge.hidden = !configured;
        group.classList.toggle('is-configured', configured);
      });
      applyMedia();
      status.textContent = t('Alterações aplicadas nesta página.');
    }
    function persist() {
      try { localStorage.setItem(key, JSON.stringify(state)); }
      catch (_) { status.textContent += t(' O navegador não permitiu salvar as preferências.'); }
    }
    function close(restoreFocus = true) {
      stopDragging();
      clearTimeout(announcementTimer);
      moveStatus.textContent = '';
      panel.hidden = true;
      trigger.setAttribute('aria-expanded', 'false');
      trigger.hidden = hideTrigger.checked;
      if (hideTrigger.checked) {
        try { localStorage.setItem(visibilityKey, 'true'); }
        catch (_) { /* The button stays hidden until this document is reloaded. */ }
      }
      if (restoreFocus && !trigger.hidden) trigger.focus();
      else if (restoreFocus) {
        const destination = document.querySelector('main, [role="main"]') || document.body;
        const previousTabindex = destination.getAttribute('tabindex');
        destination.setAttribute('tabindex', '-1');
        destination.focus({ preventScroll: true });
        destination.addEventListener('blur', () => {
          if (previousTabindex === null) destination.removeAttribute('tabindex');
          else destination.setAttribute('tabindex', previousTabindex);
        }, { once: true });
      }
    }
    trigger.addEventListener('click', event => {
      event.preventDefault();
      if (!panel.hidden) return close();
      panel.hidden = false;
      constrainPanel();
      trigger.setAttribute('aria-expanded', 'true');
      shadow.querySelector('#fm-title').focus();
    });
    shadow.querySelector('.close').addEventListener('click', () => close());
    document.addEventListener('focusin', event => {
      if (!panel.hidden && event.target !== host) close(false);
    });
    shadow.addEventListener('keydown', event => {
      if (event.key === 'Escape' && !panel.hidden) { event.preventDefault(); close(); }
    });
    shadow.querySelector('.reset').addEventListener('click', () => {
      setAllGroups(false);
      setFloating(false);
      Object.keys(state).forEach(name => {
        state[name] = 'original';
        const control = shadow.querySelector(`#fm-${name}`);
        if (control.type === 'checkbox') control.checked = false;
        else if (control.type === 'range') syncRanges.get(name)();
        else control.value = 'original';
      });
      hideTrigger.checked = false;
      compactTrigger.checked = false;
      applyCompactTrigger();
      try { localStorage.removeItem(compactKey); } catch (_) { /* Optional persistence. */ }
      apply();
      try { localStorage.removeItem(key); } catch (_) { /* Optional persistence. */ }
      status.textContent = t('Preferências restauradas.');
    });
    apply();
    if (status.textContent === t('Alterações aplicadas nesta página.')) {
      status.textContent = t('Preferências salvas apenas neste navegador, por site.');
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();
